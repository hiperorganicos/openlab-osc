#!/bin/sh
# run an OSCgroups client with some reasonable default values
./bin/OscGroupClient oscgroups.iua.upf.edu 22242 22243 22244 22245 test_user abc123 test_group xyz345
